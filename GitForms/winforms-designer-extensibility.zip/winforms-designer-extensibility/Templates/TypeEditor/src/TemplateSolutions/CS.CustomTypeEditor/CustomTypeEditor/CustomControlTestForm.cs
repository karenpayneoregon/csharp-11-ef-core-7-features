namespace CustomTypeEditorTest
{
    public partial class CustomControlTestForm : Form
    {
        public CustomControlTestForm()
        {
            InitializeComponent();
        }
    }
}