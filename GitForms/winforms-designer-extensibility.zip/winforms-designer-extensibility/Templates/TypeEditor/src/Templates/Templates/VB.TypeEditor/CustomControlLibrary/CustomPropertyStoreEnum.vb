﻿''' <summary>
'''  Custom enum used in <see cref="CustomPropertyStore"/>.
''' </summary>
Public Enum CustomPropertyStoreEnum
    FirstValue
    SecondValue
    ThirdValue
    FourthValue
End Enum
