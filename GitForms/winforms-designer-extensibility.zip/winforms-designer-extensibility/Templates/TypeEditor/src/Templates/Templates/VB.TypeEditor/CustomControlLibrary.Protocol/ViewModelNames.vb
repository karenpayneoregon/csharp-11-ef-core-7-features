﻿''' <summary>
'''  Static class for holding the names of all ViewModels to provide IntelliSense support.
''' </summary>
Public Module ViewModelNames
    Public Const CustomTypeEditorVM As String = NameOf(CustomTypeEditorVM)
End Module
