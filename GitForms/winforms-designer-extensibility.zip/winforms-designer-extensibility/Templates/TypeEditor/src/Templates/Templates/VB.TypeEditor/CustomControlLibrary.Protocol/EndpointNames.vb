﻿''' <summary>
'''  Static class for holding the names of all endpoints to provide IntelliSense support.
''' </summary>
Public Module EndpointNames
    Public Const CreateCustomTypeEditorVM As String = NameOf(CreateCustomTypeEditorVM)
    Public Const CustomTypeEditorEditorOKClick As String = NameOf(CustomTypeEditorEditorOKClick)
End Module


