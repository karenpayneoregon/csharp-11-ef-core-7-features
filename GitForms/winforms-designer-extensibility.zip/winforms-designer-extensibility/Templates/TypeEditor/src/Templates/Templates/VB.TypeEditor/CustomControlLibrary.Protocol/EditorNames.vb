﻿''' <summary>
'''  Static class for holding the names of all custom type editors to provide IntelliSense support.
''' </summary>
Public Module EditorNames
    Public ReadOnly CustomTypeEditor As String = NameOf(CustomTypeEditor)
End Module

