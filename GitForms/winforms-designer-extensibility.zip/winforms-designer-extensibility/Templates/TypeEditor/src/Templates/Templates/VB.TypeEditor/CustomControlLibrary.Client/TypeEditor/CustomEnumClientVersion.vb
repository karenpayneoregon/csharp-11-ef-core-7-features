﻿''' <summary>
''' Mirror of the server-defined enum for the class 
''' which makes up the CustomControl's CustomPropertyStore property.
''' </summary>
Public Enum CustomEnumClientVersion
    FirstValue
    SecondValue
    ThirdValue
    FourthValue
End Enum
