﻿namespace WinForms.Tiles.Designer.Protocol.Endpoints
{
    public static class EndpointNames
    {
        public const string CreateTemplateAssignmentViewModel = nameof(CreateTemplateAssignmentViewModel);
        public const string TemplateAssignmentEditorOKClick = nameof(TemplateAssignmentEditorOKClick);
    }
}
