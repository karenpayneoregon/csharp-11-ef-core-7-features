﻿namespace WinForms.Tiles.Designer.Protocol
{
    public static class EditorNames
    {
        public const string TemplateAssignmentEditor = nameof(TemplateAssignmentEditor);
    }
}