﻿namespace WinForms.Tiles.Designer.Protocol
{
    public static class ViewModelNames
    {
        public const string TemplateAssignmentViewModel = nameof(TemplateAssignmentViewModel);
    }
}
