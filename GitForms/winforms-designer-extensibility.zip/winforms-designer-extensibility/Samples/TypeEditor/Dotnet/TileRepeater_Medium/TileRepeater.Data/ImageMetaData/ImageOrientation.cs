﻿namespace TileRepeater.Data.Image
{
    public enum ImageOrientation
    {
        Square,
        Portrait,
        Landscape
    }
}
