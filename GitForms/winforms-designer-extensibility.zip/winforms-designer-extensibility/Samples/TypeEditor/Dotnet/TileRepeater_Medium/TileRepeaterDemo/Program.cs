namespace TileRepeaterDemo
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();

            // Comment this line in and the next line out for running the Client/Server Demo.
            Application.Run(new MainForm());
            // Application.Run(new SimplifiedTileRepeaterTestForm());
        }
    }
}