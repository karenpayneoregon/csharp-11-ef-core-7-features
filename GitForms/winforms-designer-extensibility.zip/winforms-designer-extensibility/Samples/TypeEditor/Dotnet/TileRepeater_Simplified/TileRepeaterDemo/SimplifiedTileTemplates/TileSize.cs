﻿namespace TileRepeaterDemo.SimplifiedTileTemplates;

public enum TileSize
{
    Small = 1,
    Medium = 2,
    Large = 3
}
